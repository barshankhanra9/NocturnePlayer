# Nocturne Android Music Player — prototype

A premium-dark Android player prototype for Android 8+ (target SDK 35), designed to run on Android 15 / Moto G34.

## Implemented in this starter
- Local audio selection through Android's system file picker (no broad storage permission needed)
- Playback engine using AndroidX Media3 ExoPlayer
- Background playback service and media session, enabling Android media notification controls
- Direct HTTPS audio stream URL playback for sources you own or are authorized to use
- Dark UI, basic play/pause/previous/next controls and a session-only favourite toggle

## Not implemented yet
- Music-service catalogue/search integration
- Persistent playlists/favourites and library scanning
- Synced lyrics, scrobbling, gapless/bit-perfect output claims, USB DAC signal-path readout
- An online streaming backend or a licensed music catalogue
- APK signing / release build

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing project.
3. Let Android Studio install Android SDK Platform 35 and the required Gradle/Android plugins.
4. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
6. For installation on your Moto G34, transfer the APK and allow Android to install from that source if prompted.

This environment did not have a working Android SDK/Gradle build setup, so this source project has not been compiled or device-tested here. Do not treat it as a verified installable APK until built and tested in Android Studio.

## Online streaming requirements
The prototype accepts a direct HTTPS audio URL only. A production online catalogue requires one of:
- a provider API/SDK that explicitly permits playback, or
- a backend serving audio you own or are licensed to distribute.

A backend would typically handle authentication, catalogue metadata, signed/expiring stream URLs, rate limiting, and observability. Do not put long-lived service secrets in the APK. A backend does not itself grant rights to music.

## Technical stack
- Kotlin
- Jetpack Compose / Material 3
- AndroidX Media3 ExoPlayer + MediaSessionService
- Android system document picker

## Prototype caveats
- Previous/next controls need a queue to do useful work; the initial version has one item at a time.
- The favourite control is only in-memory and resets when the app process restarts.
- Notification permission behavior can vary by Android version/settings.
- Source format and output sample rate are not yet exposed in the UI.
