package app.nocturne.player

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.content.ContextCompat
import com.google.common.util.concurrent.ListenableFuture

private val Ink = Color(0xFF090B10)
private val Panel = Color(0xFF151923)
private val Accent = Color(0xFFB9F397)
private val Muted = Color(0xFF9299AA)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controllerState by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { controllerState = controllerFuture?.get() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this))

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, onPrimary = Ink, background = Ink, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                NocturneScreen(controllerState)
            }
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun NocturneScreen(player: MediaController?) {
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("Nothing playing") }
    var subtitle by remember { mutableStateOf("Choose a local file or enter a direct audio stream URL") }
    var isPlaying by remember { mutableStateOf(false) }
    var liked by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            title = it.lastPathSegment?.substringAfterLast('/') ?: "Local audio"
            subtitle = "Local file · device storage"
            playUri(player, it, title)
            isPlaying = true
        }
    }

    LaunchedEffect(player) {
        player?.addListener(object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaMetadataChanged(metadata: MediaMetadata) {
                title = metadata.title?.toString() ?: title
                subtitle = metadata.artist?.toString() ?: subtitle
            }
        })
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF20293A), Ink, Ink))
        )
    ) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NOCTURNE", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text("Music, uninterrupted.", color = Muted, fontSize = 13.sp)
                }
                Surface(color = Color(0xFF263044), shape = RoundedCornerShape(50)) {
                    Text("BETA 0.1", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Accent, fontSize = 11.sp)
                }
            }

            Spacer(Modifier.height(4.dp))
            Box(
                Modifier.fillMaxWidth().height(250.dp)
                    .background(Brush.linearGradient(listOf(Color(0xFF4B5C75), Color(0xFF202837), Color(0xFF11151E))), RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("N", color = Accent, fontSize = 92.sp, fontWeight = FontWeight.Light)
                    Text("SOUND IN ITS ELEMENT", color = Color.White.copy(alpha = .6f), fontSize = 10.sp, letterSpacing = 3.sp)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, color = Muted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { player?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                FilledIconButton(
                    onClick = {
                        player?.let { if (it.isPlaying) it.pause() else it.play() }
                        isPlaying = player?.isPlaying == true
                    },
                    modifier = Modifier.size(64.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent, contentColor = Ink)
                ) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(34.dp)) }
                IconButton(onClick = { player?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { liked = !liked }) {
                    Icon(Icons.Default.Favorite, null, tint = if (liked) Accent else Muted)
                }
            }

            Text("YOUR LIBRARY", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            OutlinedButton(
                onClick = { filePicker.launch(arrayOf("audio/*")) },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.FolderOpen, null)
                Spacer(Modifier.width(10.dp))
                Text("Choose music from this device")
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Link, null, tint = Accent)
                        Spacer(Modifier.width(8.dp))
                        Text("ONLINE STREAM", fontWeight = FontWeight.Bold, letterSpacing = 1.sp, fontSize = 12.sp)
                    }
                    Text("Paste a direct URL to an audio stream you own or are authorized to play.", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(
                        value = url, onValueChange = { url = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("https://example.com/track.flac") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    Button(
                        onClick = {
                            val u = url.trim()
                            if (u.startsWith("https://") && player != null) {
                                title = u.substringAfterLast('/').substringBefore('?').ifBlank { "Online stream" }
                                subtitle = "Online stream · source quality depends on provider"
                                player.setMediaItem(
                                    MediaItem.Builder().setUri(u)
                                        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist("Online stream").build())
                                        .build()
                                )
                                player.prepare()
                                player.play()
                                isPlaying = true
                            }
                        },
                        enabled = url.trim().startsWith("https://") && player != null,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)
                    ) { Text("Play stream") }
                }
            }

            Text(
                "Audio quality depends on the actual source file/stream. Nocturne does not bypass paywalls or extract protected streams.",
                color = Muted, fontSize = 11.sp
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

private fun playUri(player: MediaController?, uri: Uri, name: String) {
    player ?: return
    player.setMediaItem(
        MediaItem.Builder().setUri(uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(name).setArtist("Local audio").build())
            .build()
    )
    player.prepare()
    player.play()
}
